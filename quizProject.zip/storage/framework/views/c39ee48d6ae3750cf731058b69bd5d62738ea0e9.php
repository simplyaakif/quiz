<div>
    <div>Name: <?php echo e($name); ?></div>
    <?php if(!empty($meta["father_name"])): ?>
        <div>Father Name: <b><?php echo e($meta["father_name"]); ?></b></div>
    <?php endif; ?>
    <div>Mobile Number: <b><?php echo e($mobile); ?></b></div>
    <div>Email Address: <b><?php echo e($email); ?></b></div>
    <div>Country: <b><?php echo e($meta["country"]); ?></b></div>
    <?php if(!empty($meta["city"])): ?>
        <div>City: <b><?php echo e($meta["city"]); ?></b></div>
    <?php endif; ?>
    <?php if(!empty($meta["address"])): ?>
        <div>Address: <b><?php echo e($meta["address"]); ?></b></div>
    <?php endif; ?>
    <?php if(!empty($meta["profession"])): ?>
        <div>Candidate Profession: <b><?php echo e($meta["profession"]); ?></b></div>
    <?php endif; ?>

    <hr>
    <div>
        <h3>Score Achieved in MCQs</h3>
        <p style="font-size: 22px;"><?php echo e($meta["score"]); ?> out of 50 </p>
        <p>Percentage: <?php echo e($meta["score"]/50 *100); ?> %</p>
    </div>
    <hr>
    <div style="margin-top: 20px;">
        <p>Text question 01 Answer (Describe the given picture in your own words)</p>
        <?php if(!empty($meta["q1"])): ?>
            <p><?php echo e($meta["q1"]); ?></p>
        <?php else: ?>
            <p>Answer not given</p>
        <?php endif; ?>
    </div>
    <div style="margin-top: 20px;">
        <p>Text question 02 Answer (Write about a strong childhood memory...)</p>
        <?php if(!empty($meta["q2"])): ?>
            <p><?php echo e($meta["q2"]); ?></p>
        <?php else: ?>
            <p>Answer not given</p>
        <?php endif; ?>
    </div>
</div><?php /**PATH E:\Aakif Work\Websites\Managment\quiz\resources\views/evaluationMail.blade.php ENDPATH**/ ?>