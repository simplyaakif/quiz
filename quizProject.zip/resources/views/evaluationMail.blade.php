<div>
    <div>Name: {{$name}}</div>
    @if (!empty($meta["father_name"]))
        <div>Father Name: <b>{{$meta["father_name"]}}</b></div>
    @endif
    <div>Mobile Number: <b>{{$mobile}}</b></div>
    <div>Email Address: <b>{{$email}}</b></div>
    <div>Country: <b>{{$meta["country"]}}</b></div>
    @if (!empty($meta["city"]))
        <div>City: <b>{{$meta["city"]}}</b></div>
    @endif
    @if (!empty($meta["address"]))
        <div>Address: <b>{{$meta["address"]}}</b></div>
    @endif
    @if (!empty($meta["profession"]))
        <div>Candidate Profession: <b>{{$meta["profession"]}}</b></div>
    @endif

    <hr>
    <div>
        <h3>Score Achieved in MCQs</h3>
        <p style="font-size: 22px;">{{$meta["score"]}} out of 50 </p>
        <p>Percentage: {{$meta["score"]/50 *100}} %</p>
    </div>
    <hr>
    <div style="margin-top: 20px;">
        <p>Text question 01 Answer (Describe the given picture in your own words)</p>
        @if(!empty($meta["q1"]))
            <p>{{$meta["q1"]}}</p>
        @else
            <p>Answer not given</p>
        @endif
    </div>
    <div style="margin-top: 20px;">
        <p>Text question 02 Answer (Write about a strong childhood memory...)</p>
        @if(!empty($meta["q2"]))
            <p>{{$meta["q2"]}}</p>
        @else
            <p>Answer not given</p>
        @endif
    </div>
</div>